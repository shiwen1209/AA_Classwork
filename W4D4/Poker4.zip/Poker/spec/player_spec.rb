require "card"
require "player"
require "hand"

describe Card do