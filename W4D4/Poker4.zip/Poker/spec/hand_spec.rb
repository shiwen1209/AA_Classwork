# require "hand"

# describe Hand do
#     subject(:h) {Hand.new}

#     describe "#initialize" do 

#         expect {Hand.new}.to_not raise_error
#     end